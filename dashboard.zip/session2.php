<?php
session_start();

echo "Nama : ".$_SESSION['nama'];
echo "<br>Login : ".$_SESSION['login'];